-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2021 at 05:22 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srd4_spms`
--

-- --------------------------------------------------------

--
-- Table structure for table `co`
--

CREATE TABLE `co` (
  `sl` int(11) NOT NULL,
  `course_id` varchar(100) NOT NULL,
  `plo_id` int(11) NOT NULL,
  `co1` tinyint(1) NOT NULL DEFAULT 0,
  `co2` int(11) NOT NULL DEFAULT 0,
  `co3` int(11) NOT NULL DEFAULT 0,
  `co4` int(11) NOT NULL DEFAULT 0,
  `co5` int(11) NOT NULL DEFAULT 0,
  `co6` int(11) NOT NULL DEFAULT 0,
  `co7` int(11) NOT NULL DEFAULT 0,
  `co8` int(11) NOT NULL DEFAULT 0,
  `co9` int(11) NOT NULL DEFAULT 0,
  `co10` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `co`
--

INSERT INTO `co` (`sl`, `course_id`, `plo_id`, `co1`, `co2`, `co3`, `co4`, `co5`, `co6`, `co7`, `co8`, `co9`, `co10`) VALUES
(1, 'CSE401', 7, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 'CSE401', 8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 'CSE401', 9, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
(4, 'CSE401', 10, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` varchar(100) NOT NULL,
  `program_id` varchar(250) NOT NULL,
  `title` varchar(100) NOT NULL,
  `credit` double NOT NULL,
  `total_co` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `program_id`, `title`, `credit`, `total_co`) VALUES
('1416455', '1', 'CSE303', 3, 67),
('CSE301', 'CSE', 'Database Management', 3, 4),
('CSE304', 'CSE', 'Database Management', 3, 4),
('CSE304', 'CSE', 'Database Management', 3, 4),
('CSE304', 'CSE', 'Database Management', 3, 4),
('CSE401', 'CSE', 'Database Management', 3, 4);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `sl` int(11) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `course_id` varchar(100) NOT NULL,
  `exam_name` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `section` varchar(5) NOT NULL,
  `q1_mark` int(11) NOT NULL,
  `q1_co` int(11) NOT NULL,
  `q1_max` int(11) NOT NULL,
  `q2_mark` int(11) NOT NULL,
  `q2_co` int(11) NOT NULL,
  `q2_max` int(11) NOT NULL,
  `q3_mark` int(11) NOT NULL,
  `q3_co` int(11) NOT NULL,
  `q3_max` int(11) NOT NULL,
  `q4_mark` int(11) NOT NULL,
  `q4_co` int(11) NOT NULL,
  `q4_max` int(11) NOT NULL,
  `q5_mark` int(11) NOT NULL,
  `q5_co` int(11) NOT NULL,
  `q5_max` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`sl`, `student_id`, `course_id`, `exam_name`, `semester`, `section`, `q1_mark`, `q1_co`, `q1_max`, `q2_mark`, `q2_co`, `q2_max`, `q3_mark`, `q3_co`, `q3_max`, `q4_mark`, `q4_co`, `q4_max`, `q5_mark`, `q5_co`, `q5_max`) VALUES
(1, '20001', 'CSE304', 'Mid', 'Summer2021', 'A', 20, 1, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, '20001', 'CSE304', 'Final', 'Summer2021', 'A', 25, 1, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, '211190', 'CSE401', 'Mid', 'Summer2021', 'A', 25, 1, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, '211190', 'CSE401', 'Final', 'Summer2021', 'A', 43, 2, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `plo`
--

CREATE TABLE `plo` (
  `sl` int(11) NOT NULL,
  `program_id` varchar(100) NOT NULL,
  `plo_no` int(11) NOT NULL,
  `plo_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plo`
--

INSERT INTO `plo` (`sl`, `program_id`, `plo_no`, `plo_name`) VALUES
(1, '0', 1, 'Engineering Knowledge'),
(2, '0', 2, 'Requirement Analysis'),
(3, '0', 3, 'Problem Analysis'),
(4, '0', 4, 'Design'),
(5, '0', 5, 'Problem Solving'),
(6, '0', 6, 'Implementation'),
(7, 'CSE', 1, 'Engineering Knowledge'),
(8, 'CSE', 2, 'Requirement Analysis'),
(9, 'CSE', 3, 'Problem Analysis'),
(10, 'CSE', 4, 'Design'),
(11, 'CSE', 5, 'Problem Solving'),
(12, 'CSE', 6, 'Implementation');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `sl` int(11) NOT NULL,
  `id` varchar(100) NOT NULL,
  `program_name` varchar(200) NOT NULL,
  `school` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`sl`, `id`, `program_name`, `school`) VALUES
(1, '0', 'CSE303', 'Modern Science'),
(2, 'CSE', 'CSE401', 'Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `sl` int(11) NOT NULL,
  `id` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `program_id` varchar(20) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`sl`, `id`, `first_name`, `last_name`, `program_id`, `email`, `password`, `role`) VALUES
(1, '1416455', 'Sabbir', 'Rahman', 'CSE303', 'sabbir.sajan67@gmail.com', 'Sajan@10', 'admin'),
(2, '20001', 'Rabbi', 'Hossain', '12345', 'rabbi@gmail.com', 'Rabbi@10', 'student'),
(3, '211103', 'Jamil', 'Rahman', '', 'jamil@gmail.com', 'jamil@100', 'faculty'),
(4, '0', 'Mr', 'HM', '', 'hm@gmail.com', 'HM@100@100', 'hm'),
(5, '300001', 'Mr', 'Rahman', '', 'rahman@gmail.com', 'rahman@100', 'faculty'),
(6, '900001', 'mr', 'HM2', '', 'hm2@gmail.com', 'HM@100@100', 'hm'),
(7, '211190', 'Mr ', 'kabir', '', 'kabir@gmail.com', 'kabir@100', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `co`
--
ALTER TABLE `co`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `plo`
--
ALTER TABLE `plo`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`sl`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `co`
--
ALTER TABLE `co`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `plo`
--
ALTER TABLE `plo`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `program`
--
ALTER TABLE `program`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
