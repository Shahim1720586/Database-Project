<?php
    $host = 'localhost';
    $user = 'root';
    $key = '';
    $db = 'spms-g6';
    $mysql = mysqli_connect($host, $user, $key, $db);
?>