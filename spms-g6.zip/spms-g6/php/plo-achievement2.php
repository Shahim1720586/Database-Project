<?php
    require 'mysql.php';
    if(isset($_GET['dep'])){

    }
?>